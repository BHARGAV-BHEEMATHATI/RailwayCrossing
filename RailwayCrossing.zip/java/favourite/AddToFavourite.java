package favourite;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddToFavourite")
public class AddToFavourite extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String itemId = request.getParameter("id");

        // Check if the item is already in favorites
        if (isItemInFavorites(itemId)) {
            // Item is already in favorites, you can handle this case (e.g., display a message)
            response.sendRedirect("userhome.jsp?message=Item already in favorites");
            return;
        }

        // Perform necessary operations to add the item to favorites
        try {
            // Establish database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/railway", "BHARGAV2", "Bhargav666@");

            // Prepare SQL statement to insert the favorite crossing
            String sql = "INSERT INTO favourites (id, Name, Address, Landmark, Trainschedule, pname, status) "
                    + "SELECT id, Name, Address, Landmark, Trainschedule, pname, status FROM adminhome WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, itemId);

            // Execute the SQL statement
            int rowsAffected = statement.executeUpdate();

            // Close the database connection
            statement.close();
            connection.close();

            // Redirect the user back to the user home page
            response.sendRedirect("userhome.jsp");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle the exception, e.g., show an error page
            response.sendRedirect("error.jsp");
        }
    }

    // Helper method to check if the item is already in favorites
    private boolean isItemInFavorites(String itemId) {
        try {
            // Establish database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/railway", "BHARGAV2", "Bhargav666@");

            // Prepare SQL statement to check if the item is in favorites
            String sql = "SELECT COUNT(*) FROM favourites WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, itemId);

            // Execute the SQL statement
            ResultSet resultSet = statement.executeQuery();

            // Check if any records are returned
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0; // Return true if the item is in favorites
            }

            // Close the database connection
            resultSet.close();
            statement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle the exception, e.g., log an error
        }
        return false; // Return false in case of an error or no records found
    }
}
