package favourite;


import java.io.IOException; 
import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement; 
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


public class DeleteRecord extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
		String id = request.getParameter("id"); 
		// Check if ID is provided
		if (id != null && !id.isEmpty()) { 
			try { 
				// Database connection details 
				String url = "jdbc:mysql://localhost:3306/railway"; 
				String user = "BHARGAV2";
				String password = "Bhargav666@"; 
				// Create database connection
				Connection conn = DriverManager.getConnection(url, user, password); 
				// Prepare and execute the delete statement 
				String sql = "DELETE FROM adminhome WHERE id = ?"; 
				PreparedStatement pstmt = conn.prepareStatement(sql); 
				pstmt.setString(1, id); 
				pstmt.executeUpdate(); 
				// Close resources 
				pstmt.close(); 
				conn.close(); 
				// Redirect back to delete.jsp with success message 
				response.sendRedirect("adminhome.jsp"); 
				} catch (SQLException e) { 
					e.printStackTrace(); 
					// Handle database errors 
					response.sendRedirect("delete.jsp?error=true");
				}
				
			}else {
				response.sendRedirect("delete.jsp?error=true");
			}
		}
	}