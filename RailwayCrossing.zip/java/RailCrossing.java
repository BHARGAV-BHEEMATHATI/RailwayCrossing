import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/RailCrossing")
public class RailCrossing extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Modify these variables with your actual database details
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/railway";
    private static final String JDBC_USER = "BHARGAV2";
    private static final String JDBC_PASSWORD = "Bhargav666@";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve form parameters
        String name = request.getParameter("Name");
        String address = request.getParameter("Address");
        String landmark = request.getParameter("Landmark");
        String timeSchedule = request.getParameter("Trainschedule");
        String personInCharge = request.getParameter("pname");
        String status = request.getParameter("status");

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Load the JDBC driver (replace "com.mysql.cj.jdbc.Driver" with your actual driver)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);

            // Prepare the SQL statement (replace "your_table" and field names with your actual values)
            String sql = "INSERT INTO railway.adminhome (Name, Address, Landmark, Trainschedule, Pname, Status) VALUES (?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);

            // Set values for the prepared statement
            pstmt.setString(1, name);
            pstmt.setString(2, address);
            pstmt.setString(3, landmark);
            pstmt.setString(4, timeSchedule);
            pstmt.setString(5, personInCharge);
            pstmt.setString(6, status);

            // Execute the update
            pstmt.executeUpdate();

            // Display a simple response to the user
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Rail Crossing Added</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h2>Rail Crossing Added Successfully!</h2>");
            out.println("<a href='adminhome.jsp'>MAIN PAGE</a>");
            out.println("</body>");
            out.println("</html>");
        } catch (ClassNotFoundException | SQLException e) {
            // Handle exceptions appropriately (e.g., log or display an error message)
            e.printStackTrace();
        } finally {
            // Close resources in the finally block to ensure they are always closed
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
